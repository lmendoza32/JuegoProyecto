package com.example.juegoproyecto

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import kotlin.random.Random

class GameActivity : AppCompatActivity() {

    private lateinit var guessEditText: EditText
    private lateinit var guessButton: Button
    private lateinit var messageTextView: TextView

    private var secretNumber: Int = 0
    private var guesses: Int = 0

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_game)

        guessEditText = findViewById(R.id.guessEditText)
        guessButton = findViewById(R.id.guessButton)
        messageTextView = findViewById(R.id.messageTextView)

        generateSecretNumber()

        guessButton.setOnClickListener {
            checkGuess()
        }
    }

    private fun generateSecretNumber() {
        secretNumber = Random.nextInt(1, 101)
    }

    private fun checkGuess() {
        val guessText = guessEditText.text.toString()

        if (guessText.isNotEmpty()) {
            val guess = guessText.toInt()
            guesses++

            if (guess == secretNumber) {
                showGameResult("¡Felicidades! Adivinaste el número en $guesses intentos.")
            } else if (guess < secretNumber) {
                showMessage("El número es mayor.")
            } else {
                showMessage("El número es menor.")
            }

            guessEditText.text.clear()
        }
    }

    private fun showMessage(message: String) {
        messageTextView.text = message
    }

    private fun showGameResult(result: String) {
        messageTextView.text = result
        guessButton.isEnabled = false
    }
}